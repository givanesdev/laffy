"use client";

import {
  Button, Checkbox, Modal,
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeadCell,
  TableRow,
} from 'flowbite-react';
import {useRef, useState} from 'react';
import SortableTableHead from "@/app/finance/SortableTableHead";
import Link from "next/link";
import {useAppStore} from "@/store/provider";
import {MdCheckCircle} from "react-icons/md";
import Approve from "@/app/claim/Approve";
import {Payment} from "@/store/store";
import PaymentFilter, {PaymentFilterInput} from "@/app/finance/PaymentFilter";


export default function Finances() {
  const {
    pages: {finance: sortState},
    finances,
    updatePayment, applyPaymentFilter,
    sortFinanceTable: sortDispatch
  } = useAppStore(store => store)
  const [openModal, setOpenModal] = useState(false);
  const [approvalPayment, setApprovalPayment] = useState<Payment | undefined>(undefined);
  const approveFormRef = useRef<HTMLFormElement>(null);
  const payments = finances.filter(f => {
    if (sortState.filter.facility)
      return f.providerName === sortState.filter.facility
    if (sortState.filter.status)
      return f.status === sortState.filter.status
    return true;
  })

  enum Status {
    Approved = 'Approved',
    Approve = 'Approve',
    Pending = 'Pending',
    Rejected = 'Rejected',
  }

  const statusColor = (status: string): string => {
    switch (status) {
      case Status.Approve:
        return 'text-blue-500';
      case Status.Approved:
        return 'text-green-500';
      case Status.Pending:
        return 'text-gray-500';
      default:
        return 'text-black';
    }
  };

  const approveClaim = (payment: Payment) => {
    setApprovalPayment(payment);
    setOpenModal(true);
  }

  const onAcceptApproval = (payment: Payment | undefined) => {
    setOpenModal(false);
    if (payment == undefined) return;
    updatePayment(payment)
    if (approveFormRef.current)
      approveFormRef.current.dispatchEvent(new Event("submit", {bubbles: true}))
  }

  const onClaimApproval = (paymentInput: { paidAmount: number, confirmed: boolean }) => {
    if (approvalPayment) {
      updatePayment({...approvalPayment, paidAmount: paymentInput.paidAmount})
    }
  }

  const onFilter = (data: PaymentFilterInput) => {
    applyPaymentFilter(data);
  }

  return (
    <>
      <div className={'shadow-md p-2 rounded'}>
        <section className={'flex justify-between mb-4'}>
          <h2 className={'text-3xl'}>Payments Management</h2>
        </section>

        <section id={'filters'} className={'my-5 shadow py-4 px-2 rounded-md'}>
          <PaymentFilter onSubmit={onFilter}/>
          <div id={'select-to-bank'} className={'flex justify-between items-center'}>
            <div className={'py-4 flex items-center gap-3'}>
              <Checkbox/>
              <Button size={'sm'} className={'rounded-none font-bold'} color={'info'}>Send to Bank</Button>
            </div>
            <Button size={'sm'} className={'rounded-none font-bold'} color={'success'}>Export to CSV</Button>
          </div>
        </section>

        <section className="overflow-x-auto">
          <Table>
            <TableHead className={''}>
              <Table.HeadCell className="p-4">
                <Checkbox/>
              </Table.HeadCell>
              <TableHeadCell>Claim ID#</TableHeadCell>
              <TableHeadCell>
                <SortableTableHead
                  title={'Patient Name'}
                  sortOrder={sortState.sortOrder}
                  sortedColumn={sortState.sortColumn}
                  activeColumn={2}
                  sortDispatch={sortDispatch}/>
              </TableHeadCell>
              <TableHeadCell>
                <SortableTableHead
                  title={'Health Facility'}
                  sortOrder={sortState.sortOrder}
                  sortedColumn={sortState.sortColumn}
                  activeColumn={3}
                  sortDispatch={sortDispatch}/>
              </TableHeadCell>
              <TableHeadCell>
                <SortableTableHead
                  title={'Date Created'}
                  sortOrder={sortState.sortOrder}
                  sortedColumn={sortState.sortColumn}
                  activeColumn={4}
                  sortDispatch={sortDispatch}/>
              </TableHeadCell>
              <TableHeadCell>
                <SortableTableHead
                  title={'Last Updated'}
                  sortOrder={sortState.sortOrder}
                  sortedColumn={sortState.sortColumn}
                  activeColumn={5}
                  sortDispatch={sortDispatch}/>
              </TableHeadCell>
              <TableHeadCell>Amount</TableHeadCell>
              <TableHeadCell className={"text-nowrap"}>Paid Amount</TableHeadCell>
              <TableHeadCell className={"text-nowrap"}>Partial</TableHeadCell>
              <TableHeadCell>
                <SortableTableHead
                  title={'Status'}
                  sortOrder={sortState.sortOrder}
                  sortedColumn={sortState.sortColumn}
                  activeColumn={6}
                  sortDispatch={sortDispatch}/>
              </TableHeadCell>
              <TableHeadCell><span className="sr-only">Actions</span></TableHeadCell>
            </TableHead>
            <TableBody className="divide-y">
              {payments.map(c => (
                <TableRow key={c.claimId} className="bg-white dark:border-gray-700 dark:bg-gray-800">
                  <Table.Cell className="p-4">
                    <Checkbox/>
                  </Table.Cell>
                  <TableCell className="whitespace-nowrap font-bold text-blue-900 dark:text-white">
                    <Link href={'/claim/{c.claimId}'}>
                      {c.claimId}
                    </Link>
                  </TableCell>
                  <TableCell>{c.patientName}</TableCell>
                  <TableCell>{c.providerName}</TableCell>
                  <TableCell>{c.createdAt}</TableCell>
                  <TableCell>{c.updatedAt}</TableCell>
                  <TableCell>{c.amount}</TableCell>
                  <TableCell>{c.paidAmount}</TableCell>
                  <TableCell>
                    {c.paidAmount < c.amount && (<MdCheckCircle color={"green"} size={"22"}/>)}
                  </TableCell>
                  <TableCell className={`${statusColor(c.status)} font-bold`}>{c.status}</TableCell>
                  <TableCell>
                    {c.status == Status.Pending && (
                      <Button color={'failure'} className={'text-nowrap'} outline size={'sm'}>Reject</Button>
                    )}
                    {c.status == Status.Approved && (
                      <Button color={'success'} className={'text-nowrap'} outline size={'sm'}>Send to Bank</Button>
                    )}
                    {c.status == Status.Approve && (
                      <Button
                        color={'info'} outline size={'sm'}
                        onClick={() => approveClaim(c)}>
                        Approve
                      </Button>
                    )}
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </section>

        <Modal show={openModal && approvalPayment !== undefined} onClose={() => setOpenModal(false)}>
          <Modal.Header>Claim Payment Approval</Modal.Header>
          <Modal.Body>
            <div className="space-y-6">
              {approvalPayment && <Approve payment={approvalPayment} onSubmit={onClaimApproval} form={approveFormRef}/>}
            </div>
          </Modal.Body>
          <Modal.Footer className={"justify-end"}>
            <Button onClick={() => onAcceptApproval(approvalPayment)}>I accept</Button>
            <Button color="gray" onClick={() => setOpenModal(false)}>
              Decline
            </Button>
          </Modal.Footer>
        </Modal>
      </div>
    </>
  );
}

