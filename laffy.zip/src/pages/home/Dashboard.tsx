import CountCard from '@/pages/home/CountCard.tsx';
import {ReactChart} from '@/components/ReactChart.tsx';
import {chartSummary} from '@/pages/home/data.ts';


export default function Dashboard() {
  const summary = {
    claims: {
      processed: 100,
      inProgress: 1,
      pending: 720,
      rejected: 21,
    },
    payments: {
      outstanding: 10,
      total: 10,
    },
  };

  return (
    <>
      <div className={'shadow-md p-2 my-3 rounded'}>
        <div className={'flex justify-between'}>
          <h2 className={'text-3xl'}>Dashboard</h2>
        </div>
      </div>

      <br />

      <section>
        <p className={'text-2xl my-3 font-bold'}>
          Claims Overview
        </p>
        <div className={'sm:flex sm:flex-col md:flex-row md:flex gap-3'}>
          <CountCard title={'Claims Processed'} count={summary.claims.processed} />
          <CountCard title={'Claims In-Progress'} count={summary.claims.inProgress} />
          <CountCard title={'Claims Pending'} count={summary.claims.pending} />
          <CountCard title={'Claims Rejected'} count={summary.claims.rejected} />
        </div>
      </section>

      <br />
      <section>
        <p className={'text-2xl my-3 font-bold'}>
          Payment Summary
        </p>
        <div className={'sm:flex sm:flex-col md:flex-row md:flex gap-3'}>
          <CountCard title={'Outstanding Payment'} count={summary.payments.outstanding} currency />
          <CountCard title={'Total Paid'} count={summary.payments.total} currency />
        </div>
      </section>

      <br />
      <section>
        <p className={'text-2xl my-3 font-bold'}>
          Finance Overview
        </p>
        <div className={'flex justify-between shadow-md p-3 border-t rounded-md'}>
          <div className={'h-96'}>
            <ReactChart
              type={'pie'}
              data={chartSummary.monthlyExpenditure.chart.data}
              options={chartSummary.monthlyExpenditure.chart.options} />
          </div>

          <div className={'h-96'}>
            <ReactChart
              type={'line'}
              data={chartSummary.claimsTrends.chart.data}
              options={chartSummary.claimsTrends.chart.options} />
          </div>

        </div>
      </section>
    </>
  );
}
