import {Button, Table, TableBody, TableCell, TableHead, TableHeadCell, TableRow} from "flowbite-react";

export default function ClaimForm() {
    const claims = [
        {
            claimId: "K-3321RE",
            date: "2024-12-05",
            procedureCode: "T54",
            description: "simple description",
            providerId: "RET53-43",
            dx: 32143,
            qty: 32,
            unitPrice: 432.43,
            total() {
                return this.qty * this.unitPrice;
            },
            insurance: "Jubilee",
            patient: "Jane Doe",
        },
        {
            claimId: "K-3421RE",
            date: "2024-12-05",
            procedureCode: "T54",
            description: "simple description",
            providerId: "RET53-43",
            dx: 3243,
            qty: 13,
            unitPrice: 32.43,
            total() {
                return this.qty * this.unitPrice;
            },
            insurance: "Jubilee",
            patient: "Jane Doe",
        }
    ];
    return (
        <div className="overflow-x-auto shadow-md">
            <Table>
                <TableHead className={"text-center"}>
                    <TableHeadCell>#</TableHeadCell>
                    <TableHeadCell>Date</TableHeadCell>
                    <TableHeadCell>Procedure Code</TableHeadCell>
                    <TableHeadCell>
                        Service Description {' '}
                        <span className={"claim-column-sm-header"}>(consultations, procedures and medical acts)</span>
                    </TableHeadCell>
                    <TableHeadCell>Provider Council ID</TableHeadCell>
                    <TableHeadCell>Dx #</TableHeadCell>
                    <TableHeadCell>Qty</TableHeadCell>
                    <TableHeadCell>Unit Price</TableHeadCell>
                    <TableHeadCell>Total</TableHeadCell>
                    <TableHeadCell>Insurance</TableHeadCell>
                    <TableHeadCell>Patient</TableHeadCell>
                    <TableHeadCell>
                        <span className="sr-only">Action</span>
                    </TableHeadCell>
                </TableHead>
                <TableBody className="divide-y">
                    {claims.map(c => (
                        <TableRow className="bg-white dark:border-gray-700 dark:bg-gray-800">
                            <TableCell className="whitespace-nowrap font-medium text-gray-900 dark:text-white">
                                {c.claimId}
                            </TableCell>
                            <TableCell>{c.date}</TableCell>
                            <TableCell>{c.procedureCode}</TableCell>
                            <TableCell>{c.description}</TableCell>
                            <TableCell>{c.providerId}</TableCell>
                            <TableCell>{c.dx}</TableCell>
                            <TableCell>{c.qty}</TableCell>
                            <TableCell>{c.unitPrice}</TableCell>
                            <TableCell>{c.total()}</TableCell>
                            <TableCell>{c.insurance}</TableCell>
                            <TableCell>{c.patient}</TableCell>
                            <TableCell>
                                <Button size={"sm"} color="green">Approve</Button>
                            </TableCell>
                        </TableRow>
                    ))}
                </TableBody>
            </Table>
        </div>
    );
}
