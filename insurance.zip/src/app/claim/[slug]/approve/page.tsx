"use client"

import {Button, Card, Checkbox, Label, TextInput} from "flowbite-react";
import {useParams} from "next/navigation";
import {useAppStore} from "@/store/provider";

export default function Page() {
  const {slug} = useParams();
  const claims = useAppStore(store => store.claims);
  const claim = claims.filter(c => c.claimId == slug).pop();

  return (
    <div>
      <p className={"text-center font-bold h-3"}>
        Claim Approval for
        <span className={"ps-1 italic text-blue-500"}>{claim?.claimId}</span>
      </p>

      <div>
        <Card className={"w-1/2 mx-auto my-5"}>
          <form className="flex mx-auto w-full flex-col gap-4">
            <div>
              <div className="mb-2 block">
                <Label htmlFor="paidAmount" value="Amount"/>
              </div>
              <TextInput id="paidAmount" type="number" placeholder={"500"} required/>
            </div>
            <div className="flex items-center gap-2">
              <Checkbox id="remember"/>
              <Label htmlFor="remember">Confirm</Label>
            </div>
            <Button type="submit">Approve</Button>
          </form>
        </Card>
      </div>
    </div>
  )
}
