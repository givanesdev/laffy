import {Button, Card, Checkbox, FileInput, Label, TextInput} from 'flowbite-react';

export default function AddInsurerForm() {
  return (
    <>
      <div className={'shadow-md p-4 my-3 rounded'}>
        <h2 className={'text-3xl text-center'}>Add Insurer</h2>
      </div>
      <div className="flex justify-center m-auto shadow-md">
        <Card className={'w-full'}>
          <form className="flex w-1/2 mx-auto flex-col gap-4">
            <div>
              <div className="mb-2 block">
                <Label htmlFor="email1" value="Email" />
              </div>
              <TextInput id="email1" type="email" placeholder="name@flowbite.com" required />
            </div>
            <div>
              <div className="mb-2 block">
                <Label htmlFor="insurerId" value="Insurer ID" />
              </div>
              <TextInput id="insurerId" type="text" required />
            </div>
            <div>
              <div className="mb-2 block">
                <Label htmlFor="name" value="Name" />
              </div>
              <TextInput id="name" type="text" required />
            </div>
            <div>
              <div className="mb-2 block">
                <Label htmlFor="phoneNo" value="Phone number #" />
              </div>
              <TextInput id="phoneNo" type="text" required />
            </div>

            <div id="fileUpload" className="max-w-md">
              <div className="mb-2 block">
                <Label htmlFor="file" value="KRA Pin" />
              </div>
              <FileInput id="file" helperText="" />
            </div>

            <div id="fileUpload" className="max-w-md">
              <div className="mb-2 block">
                <Label htmlFor="file" value="Business License" />
              </div>
              <FileInput id="file" helperText="" />
            </div>

            <div className="flex items-center gap-2">
              <Checkbox id="remember" />
              <Label htmlFor="remember">Accept terms</Label>
            </div>


            <Button type="submit">Submit</Button>
          </form>
        </Card>
      </div>
    </>
  )
    ;
}
