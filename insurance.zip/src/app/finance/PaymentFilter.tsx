import {Button, Select, TextInput} from "flowbite-react";
import {SlCalender} from "react-icons/sl";
import {FaSearch} from "react-icons/fa";
import {ChangeEvent, useState} from "react";

enum Status {
  Approved = 'Approved',
  Approve = 'Approve',
  Pending = 'Pending',
  Rejected = 'Rejected',
}

export interface PaymentFilterInput {
  fromDate: string
  toDate: string
  membership: string
  facility: string
  status: string
}

type PaymentFilterProps = {
  onSubmit?: (data: PaymentFilterInput) => void
}

export default function PaymentFilter(props: PaymentFilterProps) {
  const healthFacilities = ['Jubilee', 'Amco', 'Life'];
  const [formData, setFormData] = useState<PaymentFilterInput>({
    fromDate: "",
    toDate: "",
    membership: "",
    facility: "",
    status: "",
  })

  const onInputChange = (field: string, e: ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
    setFormData((f) => ({...f, [field]: e.target.value}))
  }

  const onSubmit = () => {
    if (props.onSubmit)
      props.onSubmit(formData)
  };

  return (
    <div className={'flex justify-between gap-2'}>
      <div className="max-w-md">
        <TextInput
          addon={
            <span className={'flex justify-center items-center'}><SlCalender/>
                  <span className={'text-nowrap ps-2'}>From Date</span></span>
          }
          id="fromDate" name="fromDate" type="date" required
          onChange={(e) => onInputChange("fromDate", e)}/>
      </div>
      <div className="max-w-md">
        <TextInput
          addon={
            <span className={'flex justify-center items-center'}><SlCalender/>
                  <span className={'text-nowrap ps-2'}>To Date</span></span>
          }
          id="fromDate" name="fromDate" type="date" required
          onChange={(e) => onInputChange("toDate", e)}
        />
      </div>
      <div className="max-w-md">
        <TextInput
          icon={FaSearch} id="membership" name="membership" type="text" placeholder={'Membership #'}
          required
          onChange={(e) => onInputChange("membership", e)}/>
      </div>
      <div className="max-w-md">
        <Select id="countries" required onChange={(e) => onInputChange("facility", e)}>
          <option value={""}>Please select Health Facility</option>
          {Object.values(healthFacilities).map(facility => (
            <option key={facility}>{facility}</option>
          ))}
        </Select>
      </div>
      <div className="max-w-md">
        <Select id="countries" required onChange={(e) => onInputChange("status", e)}>
          <option value={""}>Please select status</option>
          {Object.values(Status).map(state => (
            <option key={state}>{state}</option>
          ))}
        </Select>
      </div>

      <Button className={"rounded-none"} onClick={onSubmit}>Filter</Button>
    </div>
  )
}
