import SimpleNavigation from "@/components/SimpleNavigation";
import Navigation from "@/components/Navigation";

export default function NavLayout({children}: { children: React.ReactNode }) {
  const authenticated = true;
  return (
    <>
      <header>{authenticated ? <Navigation/> : <SimpleNavigation/>}</header>
      <main className={'xl:container xl:mx-auto p-6 mt-6'}>
        {children}
      </main>
    </>
  );
}
