import {Badge} from 'flowbite-react';

export default function Notification(){
  const notifications = [{}];
  return (
    <div className={"absolute bottom-3 right-1"}>
      <Badge color={"failure"} className={"px-2 font-bold rounded-full"}>{notifications.length}</Badge>
    </div>
  );
}
