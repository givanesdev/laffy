import './App.css';
import {createBrowserRouter} from 'react-router';
import {
  DashboardPage,
  HomePage,
  InsurerFormPage,
  InsurerPage,
  ProviderFormPage,
  ProviderPage,
  PatientsFormPage,
  PatientsPage,
  SettingsPage,
} from '@/pages';
import {ReactChart} from '@/components/ReactChart.tsx';
import {
  BarController,
  LinearScale,
  BarElement,
  TimeScale,
  Tooltip,
} from 'chart.js';
import AuthLayout from '@/layout/AuthLayout.tsx';

ReactChart.register(BarController, LinearScale, BarElement, TimeScale, Tooltip);

function App() {
  return createBrowserRouter([
    {path: '/', element: <HomePage />},
    {
      element: <AuthLayout />, children: [
        {path: '/dashboard', element: <DashboardPage />},
        {path: '/insurer', element: <InsurerPage />},
        {path: '/insurer/form', element: <InsurerFormPage />},
        {path: '/settings', element: <SettingsPage />},
        {path: '/patients', element: <PatientsPage />},
        {path: '/patients/form', element: <PatientsFormPage />},
        {path: '/providers', element: <ProviderPage />},
        {path: '/providers/form', element: <ProviderFormPage />},
      ],
    },
  ]);
}

export default App;
