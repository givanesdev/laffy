export const data = {
    claims: [
        {
            claimId: "K-3321RE",
            date: "2024-12-05",
            procedureCode: "T54",
            description: "simple description",
            providerId: "RET53-43",
            dx: 32143,
            qty: 32,
            unitPrice: 432.43,
            total() {
                return this.qty * this.unitPrice;
            },
            insurance: "Jubilee",
            patient: "Jane Doe",
        },
        {
            claimId: "K-3421RE",
            date: "2024-12-05",
            procedureCode: "T54",
            description: "simple description",
            providerId: "RET53-43",
            dx: 3243,
            qty: 13,
            unitPrice: 32.43,
            total() {
                return this.qty * this.unitPrice;
            },
            insurance: "Jubilee",
            patient: "Jane Doe",
        }
    ],
    finances: [
        {
            claimId: 'K-3321RE',
            patientName: 'Jane Doe',
            providerName: 'Jubilee',
            amount: 645.46,
            status: 'Approve',
            createdAt: '2024-12-10 08:40',
            updatedAt: '2024-12-10 08:51',
        },
        {
            claimId: 'K-8921RF',
            patientName: 'Jane Doe',
            providerName: 'Amco',
            amount: 645.46,
            status: 'Pending',
            createdAt: '2024-12-12 00:02',
            updatedAt: '2024-12-12 01:51',
        },
        {
            claimId: 'K-8923RF',
            patientName: 'Jane Doe',
            providerName: 'Jubilee',
            amount: 645.46,
            status: 'Approved',
            createdAt: '2024-12-11 16:12',
            updatedAt: '2024-12-11 17:23',
        },
    ]
}
