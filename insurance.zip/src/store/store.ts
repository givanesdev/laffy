import {createStore} from "zustand/vanilla";
import {PaymentFilterInput} from "@/app/finance/PaymentFilter";

type Insurer = {
    insurerId: string
    name: string
    patients: number
    payoutRate: string
    phone: string
    started: string
    updated: string
}

export type Payment = {
    claimId: string
    patientName: string
    providerName: string
    amount: number
    paidAmount: number
    status: string
    createdAt: string
    updatedAt: string
}

type Claim = {
    claimId: string
    date: string
    procedureCode: string
    description: string
    providerId: string
    dx: number
    qty: number
    unitPrice: number
    total: () => number
    insurance: string
    patient: string
}

type User = {
    loggedIn: boolean
}

export type AppState = {
    user?: User
    claims: Claim[]
    finances: Payment[]
    insurers: Insurer[]
    pages: {
        finance: {
            sortOrder: string
            sortColumn: number
            filter: PaymentFilterInput
        }
    }
}

export type AppActions = {
    AddClaim: (c: Claim) => void
    Login: (u: User) => void
    Logout: () => void
    updatePayment: (p: Payment) => void
    applyPaymentFilter: (f: PaymentFilterInput) => void
    sortFinanceTable: (column: number) => void
}

export type AppStore = AppState & AppActions;

export const defaultInitState: AppState = {
    claims: [
        {
            claimId: "K-3321RE",
            date: "2024-12-05",
            procedureCode: "T54",
            description: "simple description",
            providerId: "RET53-43",
            dx: 32143,
            qty: 32,
            unitPrice: 432.43,
            total() {
                return this.qty * this.unitPrice;
            },
            insurance: "Jubilee",
            patient: "Jane Doe",
        },
        {
            claimId: "K-342SRE",
            date: "2024-12-05",
            procedureCode: "T54",
            description: "simple description",
            providerId: "RET53-43",
            dx: 3243,
            qty: 13,
            unitPrice: 32.43,
            total() {
                return this.qty * this.unitPrice;
            },
            insurance: "Jubilee",
            patient: "Jane Doe",
        }
    ],
    finances: [
        {
            claimId: 'K-3321RE',
            patientName: 'Jane Doe',
            providerName: 'Jubilee',
            amount: 645.46,
            paidAmount: 600.46,
            status: 'Approve',
            createdAt: '2024-12-10 08:40',
            updatedAt: '2024-12-10 08:51',
        },
        {
            claimId: 'K-8921RF',
            patientName: 'Jane Doe',
            providerName: 'Amco',
            amount: 645.46,
            paidAmount: 200.46,
            status: 'Pending',
            createdAt: '2024-12-12 00:02',
            updatedAt: '2024-12-12 01:51',
        },
        {
            claimId: 'K-8923RF',
            patientName: 'Jane Doe',
            providerName: 'Jubilee',
            amount: 600.60,
            paidAmount: 600.60,
            status: 'Approved',
            createdAt: '2024-12-11 16:12',
            updatedAt: '2024-12-11 17:23',
        },
    ],
    insurers: [
        {
            insurerId: 'K-3321RE',
            name: 'Amco',
            patients: 10,
            payoutRate: '10%',
            phone: '234-465-4571',
            started: '2024-12-05',
            updated: '2024-12-05',
        },
        {
            insurerId: 'K-3521RE',
            name: 'Jubilee',
            patients: 10,
            payoutRate: '10%',
            phone: '234-465-4571',
            started: '2024-12-05',
            updated: '2024-12-05',
        },
    ],
    user: {loggedIn: false},
    pages: {
        finance: {
            sortOrder: "asc",
            sortColumn: 1,
            filter: {
                facility: "",
                status: "",
                fromDate: "",
                toDate: "",
                membership: ""
            }
        }
    }
}

function Logout(state: AppStore): Partial<AppState> {
    return {user: {...state.user, loggedIn: false}}
}

function Login(state: AppStore): Partial<AppState> {
    return {user: {...state.user, loggedIn: false}}
}

function updatePayment(state: AppStore, payment: Payment): Partial<AppState> {
    return {finances: [...state.finances.filter(c => c.claimId != payment.claimId), payment]}
}

function AddClaim(state: AppStore, claim: Claim): Partial<AppState> {
    return {claims: [...state.claims, claim]}
}

function applyPaymentFilter(state: AppStore, filter: PaymentFilterInput): Partial<AppState> {
    const pages = state.pages;
    return {pages: {...pages, finance: {...pages.finance, filter}}}
}

function sortFinanceTable(state: AppStore, column: number): Partial<AppState> {
    const pages = state.pages;
    if (pages.finance.sortColumn === column) {
        const order = pages.finance.sortOrder === 'asc' ? 'desc' : 'asc';
        return {pages: {...pages, finance: {...pages.finance, sortOrder: order}}}
    }

    return {pages: {...pages, finance: {...pages.finance, sortOrder: "asc", sortColumn: column}}}
}

export const createAppStore = (initState: AppState = defaultInitState) => {
    return createStore<AppStore>()((set) => ({
        ...initState,
        Logout: () => set(Logout),
        Login: () => set(Login),
        AddClaim: (c: Claim) => set((state) => AddClaim(state, c)),
        updatePayment: (p: Payment) => set((state) => updatePayment(state, p)),
        sortFinanceTable: (column) => set((state) => sortFinanceTable(state, column)),
        applyPaymentFilter: (f: PaymentFilterInput) => set((state) => applyPaymentFilter(state, f)),
    }))
};
