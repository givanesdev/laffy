"use client"

import {Button, Table, TableBody, TableCell, TableHead, TableHeadCell, TableRow} from "flowbite-react";
import Link from "next/link";
import {useAppStore} from "@/store/provider";

export default function Claims() {
    const claims = useAppStore(store => store.claims)

    return (
        <>
            <div className={"shadow-md p-2 my-3 rounded"}>
                <div className={"flex justify-between"}>
                    <h2 className={"text-3xl"}>Claims</h2>
                    <Button as={Link} href={"/claims/form"} className={"font-bold"} color={"blue"}>New Claim</Button>
                </div>
            </div>

           <div className="overflow-x-auto shadow-md">
                <Table>
                    <TableHead className={"text-center"}>
                        <TableHeadCell>#</TableHeadCell>
                        <TableHeadCell>Date</TableHeadCell>
                        <TableHeadCell>Procedure Code</TableHeadCell>
                        <TableHeadCell>
                            Service Description {' '}
                            <span
                                className={"claim-column-sm-header"}>(consultations, procedures and medical acts)</span>
                        </TableHeadCell>
                        <TableHeadCell>Provider Council ID</TableHeadCell>
                        <TableHeadCell>Dx #</TableHeadCell>
                        <TableHeadCell>Qty</TableHeadCell>
                        <TableHeadCell>Unit Price</TableHeadCell>
                        <TableHeadCell>Total</TableHeadCell>
                        <TableHeadCell>Insurance</TableHeadCell>
                        <TableHeadCell>Patient</TableHeadCell>
                        <TableHeadCell>
                            <span className="sr-only">Action</span>
                        </TableHeadCell>
                    </TableHead>
                    <TableBody className="divide-y">
                        {claims.map(c => (
                            <TableRow key={c.claimId} className="bg-white dark:border-gray-700 dark:bg-gray-800">
                                <TableCell className="whitespace-nowrap font-bold text-blue-900 dark:text-white">
                                    <Link href={"/claim/{c.claimId}"}>
                                        {c.claimId}
                                    </Link>
                                </TableCell>
                                <TableCell>{c.date}</TableCell>
                                <TableCell>{c.procedureCode}</TableCell>
                                <TableCell>{c.description}</TableCell>
                                <TableCell>{c.providerId}</TableCell>
                                <TableCell>{c.dx}</TableCell>
                                <TableCell>{c.qty}</TableCell>
                                <TableCell>{c.unitPrice}</TableCell>
                                <TableCell>{c.total()}</TableCell>
                                <TableCell>{c.insurance}</TableCell>
                                <TableCell>{c.patient}</TableCell>
                                <TableCell>
                                    <Button size={"sm"} color="green">Approve</Button>
                                </TableCell>
                            </TableRow>
                        ))}
                    </TableBody>
                </Table>
            </div>
        </>
    );
}
