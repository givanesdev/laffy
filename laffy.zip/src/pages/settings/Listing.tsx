import {Button, Card, Checkbox, Label, ListGroup, Table, TextInput} from 'flowbite-react';
import {MdOutlineAttachMoney} from 'react-icons/md';
import {HiOutlineAdjustments} from 'react-icons/hi';
import {useState} from 'react';

export default function Listing() {
  const [activeTab, setTab] = useState<number>(1);
  const limits = [
    {
      created: '2024-12-12 14:56',
      limit: 2000000,
      current: 2040080,
    },
    {
      created: '2024-11-02 04:11',
      limit: 2000000,
      current: 2040080,
    },
  ];
  return (
    <div className="flex shadow min-h-full">
      <div>
        <ListGroup className="w-48 border-none">
          <ListGroup.Item
            style={
              {
                borderTopRightRadius: 0,
                borderTopLeftRadius: 4,
                borderBottomLeftRadius: 0,
                borderBottomRightRadius: 0,
              }}
            icon={MdOutlineAttachMoney}
            active={activeTab === 1}
            onClick={() => setTab(1)}>
            Budget
          </ListGroup.Item>
          <ListGroup.Item
            style={
              {
                borderTopRightRadius: 0,
                borderTopLeftRadius: 0,
                borderBottomLeftRadius: 4,
                borderBottomRightRadius: 0,
              }}
            icon={HiOutlineAdjustments}
            active={activeTab === 2}
            onClick={() => setTab(2)}>
            Settings
          </ListGroup.Item>
          {/*
          <ListGroup.Item icon={HiInbox}>Messages</ListGroup.Item>
          <ListGroup.Item icon={HiCloudDownload}>Download</ListGroup.Item>
*/}
        </ListGroup>
      </div>

      {/*Budget Tab*/}
      {activeTab == 1 && (
        <div className={'ps-2 w-full'}>
          <Card className={'shadow border-t-2 rounded-t w-full'}>
            <p className={'text-center text-xl font-bold'}>Budget Limit Setup</p>
            <div className={'flex justify-center'}>
              <form className="w-3/4">
                <div className={'mb-2'}>
                  <div className="mb-2 block">
                    <Label htmlFor="limit" value="Budget Limit" />
                  </div>
                  <TextInput id="limit" type="number" placeholder={'2000000'} required />
                </div>
                <div className="flex items-center gap-2 mb-2">
                  <Checkbox id="remember" />
                  <Label htmlFor="remember">Confirm</Label>
                </div>
                <Button size={'sm'} type="submit">Submit</Button>
              </form>
            </div>

            <br />
            <hr />

            <p className={'text-center text-xl font-bold'}>Limits</p>
            <div>
              <Table>
                <Table.Head>
                  <Table.HeadCell>Date Created</Table.HeadCell>
                  <Table.HeadCell>Limit Amount</Table.HeadCell>
                  <Table.HeadCell>Current Amount</Table.HeadCell>
                </Table.Head>
                <Table.Body className="divide-y">
                  {limits.map(limit => (
                    <Table.Row className="bg-white dark:border-gray-700 dark:bg-gray-800">
                      <Table.Cell className="whitespace-nowrap font-medium text-gray-900 dark:text-white">
                        {limit.created}
                      </Table.Cell>
                      <Table.Cell>{limit.limit}</Table.Cell>
                      <Table.Cell>{limit.current}</Table.Cell>
                    </Table.Row>
                  ))}
                </Table.Body>
              </Table>
            </div>
          </Card>
        </div>
      )}

      {/*Settings Tab*/}
      {activeTab == 2 && (
        <div className={'ps-2 w-full'}>
          <Card className={'shadow border-t-2 rounded-t w-full'}>
            <p className={'text-center text-xl font-bold'}>Limits</p>
            <div></div>
          </Card>
        </div>
      )}
    </div>
  );
}

