import {ChartData, ChartOptions} from 'chart.js';

type SummaryChartData = {
    chart: {data: ChartData, options: ChartOptions}
};
type Summary = {
    monthlyExpenditure: SummaryChartData
    claimsTrends: SummaryChartData
}
export const chartSummary: Summary = {
    monthlyExpenditure: {
        chart: {
            options: {
                plugins: {
                    title: {
                        display: true,
                        text: 'Monthly Expenditure',
                        font: {
                            size: 18,
                        },
                    },
                    legend: {
                        position: 'bottom',
                        labels: {
                            font: {
                                size: 18,
                            },
                        },
                    },
                },
            },
            data: {
                labels: [
                    'Inpatient',
                    'out patient',
                    'pharmaceuticals',
                    'others',
                ],
                datasets: [{
                    label: 'My First Dataset',
                    data: [300, 50, 100, 78],
                    backgroundColor: [
                        'rgb(255, 99, 132)',
                        'rgb(54, 162, 235)',
                        'rgb(255, 205, 86)',
                        'rgb(55, 205, 86)',
                    ],
                    hoverOffset: 4,
                }],
            },
        },
    },
    claimsTrends: {
        chart: {
            options: {
                plugins: {
                    title: {
                        display: true,
                        text: 'Claims Trend',
                        font: {
                            size: 18,
                        },
                    },
                    legend: {
                        position: 'bottom',
                        labels: {
                            font: {
                                size: 18,
                            },
                        },
                    },
                },
            },
            data: {
                labels: ['J', 'F', 'M', 'A', 'M', 'J', 'J'],
                datasets: [{
                    label: '',
                    data: [65, 59, 80, 81, 56, 55, 40],
                    fill: false,
                    borderColor: 'rgb(75, 192, 192)',
                    tension: 0.1,
                }],
            },
        },
    },
};
