"use client"

import {Checkbox, Label, TextInput} from "flowbite-react";
import {Payment} from "@/store/store";
import {FormEventHandler, LegacyRef, RefObject, useRef} from "react";

type ApproveProps = {
  payment: Payment
  form?: RefObject<HTMLFormElement>
  onSubmit?: ({paidAmount, confirmed}: { paidAmount: number, confirmed: boolean }) => void
};

export default function Approve(props: ApproveProps) {
  const amountRef = useRef<HTMLInputElement>();
  const confirmedRef = useRef<HTMLInputElement>();

  const onApproval: FormEventHandler<HTMLFormElement> = (e) => {
    if (props.onSubmit)
      props.onSubmit({
        paidAmount: Number(amountRef.current?.value ?? "0"),
        confirmed: confirmedRef.current?.checked ?? false
      })
    e.preventDefault();
  }

  return (
    <div>
      <div>
        <div className={"w-full mx-auto my-5"}>
          <div className="flex mx-auto w-full flex-col gap-4">
            <form ref={props.form} onSubmit={onApproval}>
              <div className={"mb-2"}>
                <div className="mb-2 block">
                  <Label htmlFor="paidAmount" value="Amount"/>
                </div>
                <TextInput
                  ref={amountRef as LegacyRef<HTMLInputElement>}
                  id="Amount"
                  type="number"
                  defaultValue={props.payment.amount}
                  disabled/>
              </div>

              <div className={"mb-2"}>
                <div className="mb-2 block">
                  <Label htmlFor="paidAmount" value="Paid Amount"/>
                </div>
                <TextInput
                  ref={amountRef as LegacyRef<HTMLInputElement>}
                  id="paidAmount"
                  type="number"
                  defaultValue={props.payment.paidAmount}
                  min={0}
                  max={props.payment.amount}
                  required/>
              </div>
              <div className="flex items-center gap-2">
                <Checkbox ref={confirmedRef as LegacyRef<HTMLInputElement>} id="confirmAmount"
                          className={"cursor-pointer"}/>
                <Label htmlFor="confirmAmoutn" className={"cursor-pointer"}>Confirm</Label>
              </div>
            </form>
          </div>
        </div>
      </div>
    </div>
  )
}
