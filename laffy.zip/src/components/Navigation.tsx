import {Navbar, NavbarBrand, NavbarCollapse, NavbarToggle} from 'flowbite-react';
import {Link, NavLink} from 'react-router';
import Notification from '@/components/Notification.tsx';

export function Navigation() {
  return (
    <Navbar rounded className={'pt-8'}>
      <NavbarBrand as={Link} to="/">
        <img src="/favicon.ico" className="mr-3 h-6 sm:h-9" alt="Insurance Management" />
        <span
          className="self-center whitespace-nowrap text-xl font-semibold text-black">Insurance Management</span>
      </NavbarBrand>
      <NavbarToggle />
      <NavbarCollapse>
        <NavLink to="/dashboard" className={({isActive}) => isActive ? "text-red-500 font-bold": ""}>Dashboard</NavLink>
        <NavLink to="/insurer" className={({isActive}) => isActive ? "text-red-500 font-bold": ""}>Insurer</NavLink>
        <NavLink to="/patients" className={({isActive}) => isActive ? "text-red-500 font-bold": ""}>Patients</NavLink>
        <NavLink to="/providers" className={({isActive}) => isActive ? "text-red-500 font-bold": ""}>Providers</NavLink>
        <NavLink to="/settings" className={({isActive}) => isActive ? "text-red-500 font-bold relative": "relative"} >
          Settings
          <Notification />
        </NavLink>
      </NavbarCollapse>
    </Navbar>
  );
}
