import HomePage from './Home.tsx';
import PatientsPage from './patients/Listing.tsx';
import PatientsFormPage from './patients/Form.tsx';
import InsurerPage from './insurer/Listing.tsx';
import InsurerFormPage from './insurer/Form.tsx';
import DashboardPage from './home/Dashboard.tsx';
import SettingsPage from './settings/Listing.tsx'
import ProviderPage from './providers/Listing.tsx';
import ProviderFormPage from './providers/Form.tsx';

export {
    HomePage,
    InsurerPage,
    InsurerFormPage,
    PatientsPage,
    PatientsFormPage,
    DashboardPage,
    SettingsPage,
    ProviderFormPage,
    ProviderPage,
};
