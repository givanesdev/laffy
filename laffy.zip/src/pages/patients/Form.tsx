import {
    Button,
    Card, Checkbox,
    Label,
    TextInput
} from "flowbite-react";

export default function PatientForm() {
    return (
        <>
            <div className={"shadow-md p-4 my-3 rounded"}>
                <h2 className={"text-3xl text-center"}>Add Patient</h2>
            </div>
            <div className="flex justify-center m-auto shadow-md pb-5">
                <form className="w-full">
                    <Card className={"flex w-2/3 mx-auto flex-col gap-4 mb-4"}>
                        <h6 className={"font-bold"}>Health Facility</h6>

                        {/*<!-- start row -->*/}
                        <div className={"columns-2"}>
                            <div>
                                <div className="mb-2 block">
                                    <Label htmlFor="code" value="Code"/>
                                </div>
                                <TextInput id="code" type="text" required/>
                            </div>
                            <div>
                                <div className="mb-2 block">
                                    <Label htmlFor="FacilityName" value="Facility Name"/>
                                </div>
                                <TextInput id="FacilityName" type="text" required/>
                            </div>
                        </div>
                        {/*<!-- end row -->*/}

                        {/*<!-- start row -->*/}
                        <div className={"columns-2"}>
                            <div>
                                <div className="mb-2 block">
                                    <Label htmlFor="district" value="District"/>
                                </div>
                                <TextInput id="district" type="text" required/>
                            </div>
                            <div>
                                <div className="mb-2 block">
                                    <Label htmlFor="sector" value="Sector"/>
                                </div>
                                <TextInput id="sector" type="text" required/>
                            </div>
                        </div>
                        {/*<!-- end row -->*/}

                        {/*<!-- start row -->*/}
                        <div className={"columns-2"}>
                            <div>
                                <div className="mb-2 block">
                                    <Label htmlFor="contactPhone" value="Contact Phone"/>
                                </div>
                                <TextInput id="contactPhone" type="text" required/>
                            </div>
                            <div>
                                <div className="mb-2 block">
                                    <Label htmlFor="contactEmail" value="Contact Email"/>
                                </div>
                                <TextInput id="contactEmail" type="email" placeholder="name@flowbite.com" required/>
                            </div>
                        </div>
                        {/*<!-- end row -->*/}
                        <div>
                            <div className="mb-2 block">
                                <Label htmlFor="contactNames" value="Contact Names"/>
                            </div>
                            <TextInput id="contactNames" type="text" required/>
                        </div>
                    </Card>

                    <Card className={"flex w-2/3 mx-auto flex-col gap-4"}>
                        <h6 className={"font-bold"}>Patient Identification</h6>
                        <div>
                            <div className="mb-2 block">
                                <Label htmlFor="patientNames" value="Patient Names"/>
                            </div>
                            <TextInput id="patientNames" type="text" required/>
                        </div>

                        {/*<!-- start row -->*/}
                        <div className={"flex"}>
                            <div className={"w-full"}>
                                <div className="mb-2 block">
                                    <Label htmlFor="contactPhone" value="Contact Phone"/>
                                </div>
                                <TextInput id="contactPhone" type="text" required/>
                            </div>
                            <div className={"w-full"}>
                                <div className="mb-2 block">
                                    <Label htmlFor="sex" value="Sex"/>
                                </div>
                                <div className={"columns-2 px-1"}>
                                    <div>
                                        <div className="flex items-center gap-2">
                                            <Checkbox id="sexMale"/>
                                            <Label htmlFor="sexMale">Male</Label>
                                        </div>
                                    </div>
                                    <div>
                                        <div className="flex items-center gap-2">
                                            <Checkbox id="sexFemale"/>
                                            <Label htmlFor="sexFemale">Female</Label>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        {/*<!-- end row -->*/}

                        {/*<!-- start row -->*/}
                        <div className={"flex"}>
                            <div className={"w-full"}>
                                <div className="mb-2 block">
                                    <Label htmlFor="dob" value="D.O.B"/>
                                </div>
                                <TextInput id="dob" type="text" required/>
                            </div>
                            <div className={"w-full"}>
                                <div className="mb-2 block">
                                    <Label htmlFor="ambulant" value="Ambulant"/>
                                </div>
                                <div className={"columns-2 px-1"}>
                                    <div>
                                        <div className="flex items-center gap-2">
                                            <Checkbox id="ambulantYes"/>
                                            <Label htmlFor="ambulantYes">Yes</Label>
                                        </div>
                                    </div>
                                    <div>
                                        <div className="flex items-center gap-2">
                                            <Checkbox id="ambulantYes"/>
                                            <Label htmlFor="ambulantYes">No</Label>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        {/*<!-- end row -->*/}

                        <div>
                            <div className="mb-2 block">
                                <Label htmlFor="phoneNo" value="Phone No"/>
                            </div>
                            <TextInput id="phoneNo" type="text" required/>
                        </div>
                        <div>
                            <div className="mb-2 block">
                                <Label htmlFor="address" value="Address/House"/>
                            </div>
                            <TextInput id="address" type="text" required/>
                        </div>

                        {/*<!-- start row -->*/}
                        <div className={"columns-2"}>
                            <div>
                                <div className="mb-2 block">
                                    <Label htmlFor="district" value="District"/>
                                </div>
                                <TextInput id="district" type="text" required/>
                            </div>
                            <div>
                                <div className="mb-2 block">
                                    <Label htmlFor="sector" value="Sector"/>
                                </div>
                                <TextInput id="sector" type="text" required/>
                            </div>
                        </div>
                        {/*<!-- end row -->*/}

                        <div>
                            <div className="mb-2 block">
                                <Label htmlFor="village" value="Village"/>
                            </div>
                            <TextInput id="village" type="text" required/>
                        </div>
                        <Button type="submit">Submit</Button>
                    </Card>
                </form>
            </div>
        </>
    );
}
