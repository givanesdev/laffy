import {Button, Table, TableBody, TableCell, TableHead, TableHeadCell, TableRow} from "flowbite-react";
import {Link} from "react-router";

export default function Patients() {
    const patients = [
        {
            patientId: "K-3321RE",
            patientName: "Jane Doe",
            phone: "123-465-7890",
            sex: "F",
            dob: "2024-12-05",
            address: "KU, KU Road, Nairobi",
            facilityName: "KU",
        },
        {
            patientId: "K-3221RS",
            patientName: "John Doe",
            phone: "123-465-7890",
            sex: "M",
            dob: "2024-12-05",
            address: "MKU, MKU Road, Nairobi",
            facilityName: "MKU",
        },
    ];
    return (
        <>
            <div className={"shadow-md p-2 my-3 rounded"}>
                <div className={"flex justify-between"}>
                    <h2 className={"text-3xl"}>Patients</h2>
                    <Button  as={Link} to={"/patients/form"} color={"blue"}>New Patient</Button>
                </div>
            </div>
            <div className="overflow-x-auto shadow-md">
                <Table>
                    <TableHead className={""}>
                        <TableHeadCell>#</TableHeadCell>
                        <TableHeadCell>Patient Name</TableHeadCell>
                        <TableHeadCell>Contact Phone</TableHeadCell>
                        <TableHeadCell>Sex</TableHeadCell>
                        <TableHeadCell>D.O.B</TableHeadCell>
                        <TableHeadCell>Address</TableHeadCell>
                        <TableHeadCell>Facility Name</TableHeadCell>
                    </TableHead>
                    <TableBody className="divide-y">
                        {patients.map(c => (
                            <TableRow key={c.patientId} className="bg-white dark:border-gray-700 dark:bg-gray-800">
                                <TableCell className="whitespace-nowrap font-medium text-gray-900 dark:text-white">
                                    {c.patientId}
                                </TableCell>
                                <TableCell>{c.patientName}</TableCell>
                                <TableCell>{c.phone}</TableCell>
                                <TableCell>{c.sex}</TableCell>
                                <TableCell>{c.dob}</TableCell>
                                <TableCell>{c.address}</TableCell>
                                <TableCell>{c.facilityName}</TableCell>
                            </TableRow>
                        ))}
                    </TableBody>
                </Table>
            </div>
        </>
    );
}
