import Link from "next/link";
import {Navbar, NavbarBrand, NavbarCollapse, NavbarLink, NavbarToggle} from "flowbite-react";

export default function Navigation() {
    return (
        <Navbar rounded className={"pt-8"}>
            <NavbarBrand as={Link} href="/">
                <img src="/favicon.ico" className="mr-3 h-6 sm:h-9" alt="Insurance Management"/>
                <span
                    className="self-center whitespace-nowrap text-xl font-semibold text-black">Insurance Management</span>
            </NavbarBrand>
            <NavbarToggle/>
            <NavbarCollapse>
                <NavbarLink as={Link} href="/insurers">Insurers</NavbarLink>
                <NavbarLink as={Link} href="/claims">Claims</NavbarLink>
                <NavbarLink as={Link} href="/finance">Finance</NavbarLink>
            </NavbarCollapse>
        </Navbar>
    );
}
