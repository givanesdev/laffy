"use client";

import {Button, Label, Table, Textarea} from 'flowbite-react';
import {useParams, useRouter} from "next/navigation";

// type PageProps = {
//   params: Promise<{ slug: string }>
// }
export default function Page() {
  const router = useRouter();
  const {slug} = useParams();
  // const claimId = (await params).slug
  const claim = {
    claimId: 'K-3321RE',
    date: '2024-12-05',
    procedureCode: 'T54',
    description: 'simple description',
    providerId: 'RET53-43',
    dx: 32143,
    qty: 32,
    unitPrice: 432.43, idType: 'Passport', ambulant: 'yes', phone: '123-456-4631', address: '',
    serviceDetail: {
      date: '9 December 2024 01:00 AM',
      patientComplaint: 'headache', provider: '--',

    },


    total() {
      return this.qty * this.unitPrice;
    },
    insurance: 'Jubilee',
    patient: 'Jane Doe',
    serviceType: 'Hospitalization | Outpatient services',

    healthFacility: {
      name: 'Timbuktu General Hospital',
      code: '1235FC',
      district: '',
      sector: '',
      contactPhone: '123-445-7892',
      contactPerson: 'Jeffrey Dozva',
      contactEmail: '',
    },
  };


  const approveClaim = (claimID: string) => router.push(`/claim/${claimID}/approve`)

  return (
    <div className="overflow-x-auto shadow-sm rounded p-4">
      <section className={'claim-header flex justify-between mb-5'}>
        <div className={'flex font-bold'}>
          <p className={'pe-4'}>Services Types</p>
          <p>{claim.serviceType}</p>
        </div>
        <div className={'flex text-center'}>
          <Button className={'rounded-none me-4 px-3 font-bold bg-orange-500 text-white'} size={'sm'}
                  color={''}>Flag</Button>
          <Button className={'rounded-none me-4 px-3 font-bold'} size={'sm'} color={'failure'}>Reject</Button>
          <Button className={'rounded-none px-1 font-bold'} size={'sm'} color={'success'}
                  onClick={() => approveClaim(slug as string)}>Approve</Button>
        </div>
      </section>

      <section className={'claim-patient-details mb-5'}>
        <p className={'text-lg mb-3 font-bold'}>A. Patient Details</p>
        <Table>
          <Table.Body className="divide-y font-bold text-gray-700">
            <Table.Row className="">
              <Table.Cell className="">
                Name: {claim.patient}
              </Table.Cell>
              <Table.Cell></Table.Cell>
              <Table.Cell></Table.Cell>
              <Table.Cell></Table.Cell>
              <Table.Cell></Table.Cell>
            </Table.Row>
            <Table.Row className="">
              <Table.Cell className="">
                Identification: {claim.claimId}
              </Table.Cell>
              <Table.Cell>
                Type: {claim.idType}
              </Table.Cell>
              <Table.Cell></Table.Cell>
              <Table.Cell></Table.Cell>
              <Table.Cell></Table.Cell>
            </Table.Row>
            <Table.Row className="">
              <Table.Cell className="">
                DOB: {claim.date}
              </Table.Cell>
              <Table.Cell>
                Gender: {claim.idType}
              </Table.Cell>
              <Table.Cell className={'capitalize'}>
                Ambulant: {claim.ambulant}
              </Table.Cell>
              <Table.Cell></Table.Cell>
              <Table.Cell></Table.Cell>
            </Table.Row>
            <Table.Row className="">
              <Table.Cell className="">
                Phone No: {claim.phone}
              </Table.Cell>
              <Table.Cell></Table.Cell>
              <Table.Cell></Table.Cell>
              <Table.Cell></Table.Cell>
              <Table.Cell></Table.Cell>
            </Table.Row>
            <Table.Row className="">
              <Table.Cell className="">
                Address/House: {claim.address}
              </Table.Cell>
              <Table.Cell></Table.Cell>
              <Table.Cell></Table.Cell>
              <Table.Cell></Table.Cell>
              <Table.Cell></Table.Cell>
            </Table.Row>
          </Table.Body>
        </Table>
      </section>

      <section className={'claim-health-facility'}>
        <p className={'text-lg mb-3 font-bold'}>B. Health Facility</p>
        <Table>
          <Table.Body className="divide-y font-bold text-gray-700">
            <Table.Row className="">
              <Table.Cell className="">
                Facility Name: {claim.healthFacility.name}
              </Table.Cell>
              <Table.Cell></Table.Cell>
              <Table.Cell>Code: {claim.healthFacility.code}</Table.Cell>
              <Table.Cell></Table.Cell>
              <Table.Cell></Table.Cell>
            </Table.Row>
            <Table.Row className="">
              <Table.Cell className="">
                District: {claim.healthFacility.district}
              </Table.Cell>
              <Table.Cell></Table.Cell>
              <Table.Cell>
                Sector: {claim.healthFacility.sector}
              </Table.Cell>
              <Table.Cell></Table.Cell>
              <Table.Cell></Table.Cell>
            </Table.Row>
            <Table.Row className="">
              <Table.Cell className="">
                Contact Phone: {claim.healthFacility.contactEmail}
              </Table.Cell>
              <Table.Cell></Table.Cell>
              <Table.Cell>
                Contact Email: {claim.healthFacility.contactEmail}
              </Table.Cell>
              <Table.Cell></Table.Cell>
              <Table.Cell></Table.Cell>
            </Table.Row>
            <Table.Row className="">
              <Table.Cell className="">
                Contact Person: {claim.healthFacility.contactEmail}
              </Table.Cell>
              <Table.Cell></Table.Cell>
              <Table.Cell></Table.Cell>
              <Table.Cell></Table.Cell>
              <Table.Cell></Table.Cell>
            </Table.Row>
          </Table.Body>
        </Table>
      </section>

      <hr className={'border my-5 border-gray-800'}/>

      <section className={'claim-signature flex justify-between mb-5'}>
        <div className={'flex flex-col font-medium'}>
          <p>Generated by: John Doe</p>
          <p>John Doe Signature</p>
        </div>
        <div className={'flex flex-col font-medium mb-3'}>
          <p>Discharge by: John Doe</p>
          <p>John Doe Signature</p>
        </div>
      </section>

      <section className={'claim-service-details mb-5'}>
        <p className={'text-lg mb-3 font-bold'}>C. Current Service Details</p>
        <div className={'font-semibold mb-4'}>
          <p> Date: {claim.serviceDetail.date}</p>
          <p> Patient complaint: {claim.serviceDetail.patientComplaint}</p>
          <p> Name of referring provider or facility: {claim.serviceDetail.provider}</p>
        </div>

        <Table>
          <Table.Head>
            <Table.HeadCell>Service dates from</Table.HeadCell>
            <Table.HeadCell></Table.HeadCell>
            <Table.HeadCell>To date</Table.HeadCell>
            <Table.HeadCell></Table.HeadCell>
          </Table.Head>
          <Table.Body className="divide-y font-bold text-gray-700">
            <Table.Row className="">
              <Table.Cell className="">Diagnosis #</Table.Cell>
              <Table.Cell>KD-10-Code</Table.Cell>
              <Table.Cell>Description</Table.Cell>
              <Table.Cell></Table.Cell>
            </Table.Row>
            <Table.Row className="">
              <Table.Cell className="">
                1 (Primary)
              </Table.Cell>
              <Table.Cell></Table.Cell>
              <Table.Cell></Table.Cell>
              <Table.Cell></Table.Cell>
            </Table.Row>
            <Table.Row className="">
              <Table.Cell className="">
                2 (Secondary)
              </Table.Cell>
              <Table.Cell></Table.Cell>
              <Table.Cell></Table.Cell>
              <Table.Cell></Table.Cell>
            </Table.Row>
            <Table.Row className="">
              <Table.Cell className="">
                3 (Secondary)
              </Table.Cell>
              <Table.Cell></Table.Cell>
              <Table.Cell></Table.Cell>
              <Table.Cell></Table.Cell>
            </Table.Row>
          </Table.Body>
        </Table>
      </section>

      <section className={'claim-services-provided mb-5'}>
        <p className={'text-lg mb-3 font-bold'}>D. Services Provided</p>
        <Table>
          <Table.Head>
            <Table.HeadCell>#</Table.HeadCell>
            <Table.HeadCell>Date</Table.HeadCell>
            <Table.HeadCell>Service Description (Consultations, procedures and medical acts)</Table.HeadCell>
            <Table.HeadCell>Provider Council ID</Table.HeadCell>
            <Table.HeadCell>Dx #</Table.HeadCell>
            <Table.HeadCell>Qty</Table.HeadCell>
            <Table.HeadCell>Unit Price</Table.HeadCell>
            <Table.HeadCell>Total</Table.HeadCell>
            <Table.HeadCell>Insurance</Table.HeadCell>
            <Table.HeadCell>Patient</Table.HeadCell>
          </Table.Head>
          <Table.Body className="divide-y font-bold text-gray-700">
            <Table.Row className="">
              <Table.Cell></Table.Cell>
              <Table.Cell></Table.Cell>
              <Table.Cell></Table.Cell>
              <Table.Cell></Table.Cell>
              <Table.Cell></Table.Cell>
              <Table.Cell></Table.Cell>
              <Table.Cell></Table.Cell>
              <Table.Cell></Table.Cell>
              <Table.Cell></Table.Cell>
              <Table.Cell></Table.Cell>
            </Table.Row>
            <Table.Row className="">
              <Table.Cell></Table.Cell>
              <Table.Cell></Table.Cell>
              <Table.Cell></Table.Cell>
              <Table.Cell></Table.Cell>
              <Table.Cell></Table.Cell>
              <Table.Cell></Table.Cell>
              <Table.Cell></Table.Cell>
              <Table.Cell></Table.Cell>
              <Table.Cell></Table.Cell>
              <Table.Cell></Table.Cell>
            </Table.Row>
            <Table.Row className="">
              <Table.Cell></Table.Cell>
              <Table.Cell></Table.Cell>
              <Table.Cell></Table.Cell>
              <Table.Cell></Table.Cell>
              <Table.Cell></Table.Cell>
              <Table.Cell></Table.Cell>
              <Table.Cell></Table.Cell>
              <Table.Cell></Table.Cell>
              <Table.Cell></Table.Cell>
              <Table.Cell></Table.Cell>
            </Table.Row>
            <Table.Row className="">
              <Table.Cell></Table.Cell>
              <Table.Cell></Table.Cell>
              <Table.Cell></Table.Cell>
              <Table.Cell></Table.Cell>
              <Table.Cell></Table.Cell>
              <Table.Cell></Table.Cell>
              <Table.Cell></Table.Cell>
              <Table.Cell></Table.Cell>
              <Table.Cell></Table.Cell>
              <Table.Cell></Table.Cell>
            </Table.Row>
            <Table.Row className="">
              <Table.Cell></Table.Cell>
              <Table.Cell></Table.Cell>
              <Table.Cell></Table.Cell>
              <Table.Cell></Table.Cell>
              <Table.Cell></Table.Cell>
              <Table.Cell colSpan={2}>Sub-Total Procedures</Table.Cell>
              <Table.Cell>0.00</Table.Cell>
              <Table.Cell>0.00</Table.Cell>
              <Table.Cell>0.00</Table.Cell>
            </Table.Row>
          </Table.Body>
        </Table>
      </section>

      <section className={'claim-services-provided mb-5'}>
        <p className={'text-lg mb-3 font-bold'}>E. Drugs and Consumables</p>
        <Table>
          <Table.Head>
            <Table.HeadCell>#</Table.HeadCell>
            <Table.HeadCell>Date</Table.HeadCell>
            <Table.HeadCell>Item Code</Table.HeadCell>
            <Table.HeadCell>Item Description (consumables, drugs)</Table.HeadCell>
            <Table.HeadCell>Dx #</Table.HeadCell>
            <Table.HeadCell>Qty</Table.HeadCell>
            <Table.HeadCell>Unit Price</Table.HeadCell>
            <Table.HeadCell>Total</Table.HeadCell>
            <Table.HeadCell>Insurance</Table.HeadCell>
            <Table.HeadCell>Patient</Table.HeadCell>
          </Table.Head>
          <Table.Body className="divide-y font-bold text-gray-700">
            <Table.Row className="">
              <Table.Cell></Table.Cell>
              <Table.Cell></Table.Cell>
              <Table.Cell></Table.Cell>
              <Table.Cell></Table.Cell>
              <Table.Cell></Table.Cell>
              <Table.Cell></Table.Cell>
              <Table.Cell></Table.Cell>
              <Table.Cell></Table.Cell>
              <Table.Cell></Table.Cell>
              <Table.Cell></Table.Cell>
            </Table.Row>
            <Table.Row className="">
              <Table.Cell></Table.Cell>
              <Table.Cell></Table.Cell>
              <Table.Cell></Table.Cell>
              <Table.Cell></Table.Cell>
              <Table.Cell></Table.Cell>
              <Table.Cell></Table.Cell>
              <Table.Cell></Table.Cell>
              <Table.Cell></Table.Cell>
              <Table.Cell></Table.Cell>
              <Table.Cell></Table.Cell>
            </Table.Row>
            <Table.Row className="">
              <Table.Cell></Table.Cell>
              <Table.Cell></Table.Cell>
              <Table.Cell></Table.Cell>
              <Table.Cell></Table.Cell>
              <Table.Cell></Table.Cell>
              <Table.Cell></Table.Cell>
              <Table.Cell></Table.Cell>
              <Table.Cell></Table.Cell>
              <Table.Cell></Table.Cell>
              <Table.Cell></Table.Cell>
            </Table.Row>
            <Table.Row className="">
              <Table.Cell></Table.Cell>
              <Table.Cell></Table.Cell>
              <Table.Cell></Table.Cell>
              <Table.Cell></Table.Cell>
              <Table.Cell></Table.Cell>
              <Table.Cell></Table.Cell>
              <Table.Cell></Table.Cell>
              <Table.Cell></Table.Cell>
              <Table.Cell></Table.Cell>
              <Table.Cell></Table.Cell>
            </Table.Row>
            <Table.Row className="">
              <Table.Cell></Table.Cell>
              <Table.Cell></Table.Cell>
              <Table.Cell></Table.Cell>
              <Table.Cell></Table.Cell>
              <Table.Cell></Table.Cell>
              <Table.Cell colSpan={2}>Sub-Total Procedures</Table.Cell>
              <Table.Cell>0.00</Table.Cell>
              <Table.Cell>0.00</Table.Cell>
              <Table.Cell>0.00</Table.Cell>
            </Table.Row>
          </Table.Body>
        </Table>
      </section>

      <section className={'font-bold mb-3'}>
        <div className={'mb-4'}>
          <div className="mb-2 block">
            <Label htmlFor="flagInput" className={'text-xl font-bold'} value="Flag reason"/>
          </div>
          <Textarea rows={4} id="flagInput" placeholder="flag reason ..." required/>
        </div>
      </section>

      <section className={'font-bold mb-3'}>
        <p>Signatures/Approval</p>
      </section>
    </div>
  );
}
