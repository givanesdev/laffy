import {FaSortAmountDown, FaSortAmountUp} from 'react-icons/fa';

type ColumnSorterProps = {
  title: string,
  sortOrder: string,
  sortedColumn: number
  activeColumn: number
  size?: string | number
  sortDispatch: (sortColumn: number) => void
};
export default function SortableTableHead(props: ColumnSorterProps) {
  const {title, size, sortOrder, sortedColumn, activeColumn, sortDispatch} = props;
  let activeColor = 'grey';
  let icon = <FaSortAmountDown size={size ?? '16'} color={activeColor} />;

  if (sortedColumn === activeColumn) {
    activeColor ='blue';
    if (sortOrder.toLowerCase() === 'asc')
      icon = <FaSortAmountUp size={size ?? '16'} color={activeColor} />;
    else
      icon = <FaSortAmountDown size={size ?? '16'} color={activeColor} />;
  }

  return (
    <div className="flex justify-center cursor-pointer" onClick={() => sortDispatch(activeColumn)}>
      <span className="inline-block pe-2 text-nowrap">{title}</span>
      {icon}
    </div>
  );
}
