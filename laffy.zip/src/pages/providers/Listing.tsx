import {Button, Table, TableBody, TableCell, TableHead, TableHeadCell, TableRow} from 'flowbite-react';
import {Link} from 'react-router';


export default function Insurers() {
  const insurers = [
    {
      insurerId: 'K-3321RE',
      name: 'Amco',
      patients: 10,
      payoutRate: '10%',
      phone: '234-465-4571',
      started: '2024-12-05',
      updated: '2024-12-05',
    },
    {
      insurerId: 'K-3321RE',
      name: 'Jubilee',
      patients: 10,
      payoutRate: '10%',
      phone: '234-465-4571',
      started: '2024-12-05',
      updated: '2024-12-05',
    },
  ];

  return (
    <>
      <div className={'shadow-md p-2 my-3 rounded'}>
        <div className={'flex justify-between'}>
          <h2 className={'text-3xl'}>Insurers</h2>
          <Button as={Link} to={'/providers/form'} color={'blue'}>New Insurer</Button>
        </div>
      </div>
      <div className="overflow-x-auto shadow-md">
        <Table>
          <TableHead className={''}>
            <TableHeadCell>Insurer ID#</TableHeadCell>
            <TableHeadCell>Name</TableHeadCell>
            <TableHeadCell>Patients</TableHeadCell>
            <TableHeadCell>Payout Rate</TableHeadCell>
            <TableHeadCell>Phone</TableHeadCell>
            <TableHeadCell>Date Created</TableHeadCell>
            <TableHeadCell>Date Updated</TableHeadCell>
          </TableHead>
          <TableBody className="divide-y">
            {insurers.map(c => (
              <TableRow key={c.insurerId} className="bg-white dark:border-gray-700 dark:bg-gray-800">
                <TableCell className="whitespace-nowrap font-medium text-gray-900 dark:text-white">
                  {c.insurerId}
                </TableCell>
                <TableCell>{c.name}</TableCell>
                <TableCell>{c.patients}</TableCell>
                <TableCell>{c.payoutRate}</TableCell>
                <TableCell>{c.phone}</TableCell>
                <TableCell>{c.started}</TableCell>
                <TableCell>{c.updated}</TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </div>
    </>
  );

}
