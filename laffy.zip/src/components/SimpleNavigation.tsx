import { Navbar, NavbarBrand, NavbarToggle } from "flowbite-react";
import {Link} from "react-router";

export function SimpleNavigation() {
  return (
    <Navbar rounded>
      <NavbarBrand as={Link} to="/">
        <img src="/favicon.ico" className="mr-3 h-6 sm:h-9" alt="Insurance Management" />
        <span className="self-center whitespace-nowrap text-xl font-semibold text-black">Insurance Management</span>
      </NavbarBrand>
      <NavbarToggle />
    </Navbar>
  );
}
