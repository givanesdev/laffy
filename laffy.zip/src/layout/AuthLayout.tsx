import {Navigation} from '@/components/Navigation.tsx';
import {Outlet} from 'react-router';

export default function AuthLayout() {
  return (
    <>
      <header><Navigation /></header>
      <main className={'md:container md:mx-auto mt-6'}>
        <Outlet />
      </main>
    </>
  );
}
