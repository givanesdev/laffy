import {HiOutlineDotsCircleHorizontal} from 'react-icons/hi';
import {Card} from 'flowbite-react';

type CountCardProps = {
  title: string
  count: number
  currency?: boolean
};
export default function CountCard({title, count, currency}: CountCardProps) {
  return (
    <Card className={'sm:w-full md:w-1/3'}>
      <h5>{title}</h5>
      <div className={'flex justify-between items-center'}>
        <div className={'flex flex-col'}>
          <span className={'text-sm'}>Today</span>
          <HiOutlineDotsCircleHorizontal size={'24'} />
        </div>
        <p className={'flex'}>
          <span className="ps-4 text-5xl">
            {currency === true && ("$ ")}
            {count}
          </span>
        </p>
      </div>
    </Card>
  );
}
